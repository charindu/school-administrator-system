package sg.com.education.school.schooladminsystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SchoolAdminSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
