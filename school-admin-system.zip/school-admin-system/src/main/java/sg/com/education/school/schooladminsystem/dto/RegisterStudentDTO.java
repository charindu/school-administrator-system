package sg.com.education.school.schooladminsystem.dto;

import lombok.*;

import java.util.List;

@Setter
@Getter
@AllArgsConstructor
@NoArgsConstructor
public class RegisterStudentDTO {

    private String teacher;
    private List<String> students;

}
