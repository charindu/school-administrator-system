package sg.com.education.school.schooladminsystem.common.entity;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import javax.persistence.Column;
import javax.persistence.Embeddable;
import javax.validation.constraints.NotNull;
import java.io.Serializable;

@Embeddable
@Getter
@Setter
@AllArgsConstructor(staticName = "staticTeacherId")
@NoArgsConstructor
public class StudentTeacherId implements Serializable {
    @Column(name = "student_id")
    private Long studentId;
    @Column(name = "teacher_id")
    private Long teacherId;
}
