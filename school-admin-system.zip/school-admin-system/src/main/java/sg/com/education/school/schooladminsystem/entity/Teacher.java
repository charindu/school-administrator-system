package sg.com.education.school.schooladminsystem.entity;


import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.*;
import sg.com.education.school.schooladminsystem.common.entity.StudentTeacher;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "teacher")
@AllArgsConstructor
@Getter
@Setter
@NoArgsConstructor
@Builder
public class Teacher {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id", length = 100)
    private Long id;
    @Column(name = "name")
    private String name;
    @Column(name = "email")
    private String email;

    @JsonIgnore
    @ManyToMany(fetch = FetchType.LAZY, cascade = CascadeType.ALL)
    @JoinTable( name ="teacher_student",
        joinColumns = { @JoinColumn(name = "teacher_id", referencedColumnName = "id")},
        inverseJoinColumns = { @JoinColumn(name = "student_id", referencedColumnName = "id")}
    )
    private Set<Student> students = new HashSet<>();

}
