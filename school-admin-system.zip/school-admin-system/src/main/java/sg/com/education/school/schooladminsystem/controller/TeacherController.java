package sg.com.education.school.schooladminsystem.controller;


import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import sg.com.education.school.schooladminsystem.dto.CommonStudentDTO;
import sg.com.education.school.schooladminsystem.dto.DeRegisterStudentDTO;
import sg.com.education.school.schooladminsystem.dto.RegisterStudentDTO;
import sg.com.education.school.schooladminsystem.dto.TeacherDTO;
import sg.com.education.school.schooladminsystem.entity.Teacher;
import sg.com.education.school.schooladminsystem.service.TeacherService;

import java.util.List;

@RestController
@RequestMapping(value = "/api")
public class TeacherController {

    private TeacherService teacherService;

    public TeacherController(TeacherService teacherService) {
        this.teacherService = teacherService;
    }

    @PostMapping("/teachers")
    public ResponseEntity saveTeachers(@RequestBody TeacherDTO teacherDTO) {
        return new ResponseEntity(teacherService.registerNewTeacher(teacherDTO), HttpStatus.CREATED);
    }

    @PostMapping("/register")
    public ResponseEntity saveStudent(@RequestBody RegisterStudentDTO teacherDTO) {

        Teacher teacher = teacherService.registerStudents(teacherDTO);
        return new ResponseEntity(teacher, HttpStatus.NO_CONTENT);
    }

    @PostMapping("/deregister")
    public ResponseEntity deregisterStudent(@RequestBody DeRegisterStudentDTO deregisterStudentDTO) {
        Teacher teacher = teacherService.deregisterStudents(deregisterStudentDTO);
        return new ResponseEntity( teacher, HttpStatus.OK);
    }

    @GetMapping("/teachers")
    public ResponseEntity findAllTeachersWithStudents(){
        List<RegisterStudentDTO> teachersWithStudents = teacherService.findTeachersWithStudents();
        return new ResponseEntity( teachersWithStudents, HttpStatus.OK);
    }

}
