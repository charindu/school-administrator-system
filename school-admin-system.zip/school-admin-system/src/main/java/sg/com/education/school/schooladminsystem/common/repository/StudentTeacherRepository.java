package sg.com.education.school.schooladminsystem.common.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import sg.com.education.school.schooladminsystem.common.entity.StudentTeacher;
import sg.com.education.school.schooladminsystem.common.entity.StudentTeacherId;

public interface StudentTeacherRepository extends JpaRepository<StudentTeacher, StudentTeacherId> {
}
