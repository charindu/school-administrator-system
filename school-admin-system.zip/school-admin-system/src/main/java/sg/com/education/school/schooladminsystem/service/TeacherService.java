package sg.com.education.school.schooladminsystem.service;

import sg.com.education.school.schooladminsystem.dto.DeRegisterStudentDTO;
import sg.com.education.school.schooladminsystem.dto.RegisterStudentDTO;
import sg.com.education.school.schooladminsystem.dto.TeacherDTO;
import sg.com.education.school.schooladminsystem.entity.Teacher;

import java.util.List;
import java.util.Set;

public interface TeacherService {

    Teacher registerNewTeacher(TeacherDTO teacherDTO);

    Teacher registerStudents(RegisterStudentDTO teacherDTO);

    Teacher deregisterStudents(DeRegisterStudentDTO deRegisterStudentDTO);

    List<RegisterStudentDTO> findTeachersWithStudents();
}
