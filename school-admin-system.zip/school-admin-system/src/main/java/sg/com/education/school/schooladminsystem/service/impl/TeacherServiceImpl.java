package sg.com.education.school.schooladminsystem.service.impl;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import sg.com.education.school.schooladminsystem.common.entity.StudentTeacher;
import sg.com.education.school.schooladminsystem.common.repository.StudentTeacherRepository;
import sg.com.education.school.schooladminsystem.dto.DeRegisterStudentDTO;
import sg.com.education.school.schooladminsystem.dto.RegisterStudentDTO;
import sg.com.education.school.schooladminsystem.dto.StudentDTO;
import sg.com.education.school.schooladminsystem.entity.Student;
import sg.com.education.school.schooladminsystem.repository.StudentRepository;
import sg.com.education.school.schooladminsystem.dto.TeacherDTO;
import sg.com.education.school.schooladminsystem.entity.Teacher;
import sg.com.education.school.schooladminsystem.repository.TeacherRepository;
import sg.com.education.school.schooladminsystem.service.TeacherService;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
public class TeacherServiceImpl implements TeacherService {

    private TeacherRepository teacherRepository;
    private StudentRepository studentRepository;
    private StudentTeacherRepository studentTeacherRepository;

    public TeacherServiceImpl(TeacherRepository teacherRepository, StudentRepository studentRepository, StudentTeacherRepository studentTeacherRepository) {
        this.teacherRepository = teacherRepository;
        this.studentRepository = studentRepository;
        this.studentTeacherRepository = studentTeacherRepository;
    }

    @Transactional
    public Teacher registerNewTeacher(TeacherDTO teacherDTO) {
        Teacher teacher = Teacher.builder()
                          .name( teacherDTO.getName())
                          .email(teacherDTO.getEmail())
                          .build();
        return teacherRepository.save( teacher);
    }

    public Teacher registerStudents(RegisterStudentDTO registerStudentDTO) throws RuntimeException {
        Teacher teacher = teacherRepository.findByEmail( registerStudentDTO.getTeacher());
        if(teacher ==null){
            teacher = Teacher.builder()
                      .email(registerStudentDTO.getTeacher())
                      .students(new HashSet<>())
                      .build();
        }
        Set<Student> studentSet = teacher.getStudents();
        for(String studentEmail: registerStudentDTO.getStudents()){
            Student student = studentRepository.findByEmail(studentEmail);
            if(student == null){
                student = Student.builder()
                        //.name( studentDTO.getName())
                        .email( studentEmail)
                        .build();
            }
            studentSet.add(student);
        }
        teacher.setStudents(studentSet);
        return teacherRepository.save(teacher);
    }

    public Teacher deregisterStudents(DeRegisterStudentDTO deRegisterStudentDTO) {
        Teacher teacher = teacherRepository.findByEmail(deRegisterStudentDTO.getTeacher());
        teacher.getStudents().removeIf( student -> student.getEmail().equalsIgnoreCase(deRegisterStudentDTO.getStudent()));
        return teacherRepository.save(teacher);
    }

    @Override
    public List<RegisterStudentDTO> findTeachersWithStudents() {
        List<RegisterStudentDTO> registerStudentDtosList = new ArrayList<>();
        List<Teacher> teachersList = teacherRepository.findAll();
        for(Teacher teacher : teachersList){
            RegisterStudentDTO registerStudentDTO = new RegisterStudentDTO();
            registerStudentDTO.setTeacher(teacher.getEmail());
            List<String> studentEmailList = teacher.getStudents().stream()
                                         .map( student -> student.getEmail()).collect(Collectors.toList());
            registerStudentDTO.setStudents(studentEmailList);
            registerStudentDtosList.add(registerStudentDTO);
        }
        return registerStudentDtosList;
    }
}
