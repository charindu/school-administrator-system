package sg.com.education.school.schooladminsystem.controller;

import org.hibernate.validator.constraints.LuhnCheck;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import sg.com.education.school.schooladminsystem.dto.CommonStudentDTO;
import sg.com.education.school.schooladminsystem.dto.StudentDTO;
import sg.com.education.school.schooladminsystem.service.StudentService;

import java.util.List;
import java.util.Set;

@RestController
@RequestMapping(value = "/api")
public class StudentController {

    private StudentService studentService;

    public StudentController(StudentService studentService) {
        this.studentService = studentService;
    }

    @PostMapping("/students")
    public ResponseEntity saveStudent(@RequestBody StudentDTO studentDTO) {
        return new ResponseEntity(studentService.registerNewStudent(studentDTO), HttpStatus.CREATED);
    }

    @GetMapping("/commonstudents")
    public ResponseEntity findCommonStudents( @RequestParam(value="teacher") List<String> teacher) {

        Set<String> commonStudents = studentService.findCommonStudentsByTeachers(teacher);
        return new ResponseEntity(commonStudents, HttpStatus.OK);
    }
}
