package sg.com.education.school.schooladminsystem.common.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import sg.com.education.school.schooladminsystem.entity.Student;
import sg.com.education.school.schooladminsystem.entity.Teacher;

import javax.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "students_teachers")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor(staticName = "studentTeacher")
public class StudentTeacher {

    @EmbeddedId
    private StudentTeacherId studentTeacherId;

    @ManyToOne
    @MapsId("studentId")
    @JsonIgnore
    private Student student;

    @ManyToOne
    @JsonIgnore
    @MapsId("teacherId")
    private Teacher teacher;

    @Column(name = "remove_reason")
    private String removeReason;
    @Column(name = "remove_date")
    private LocalDateTime removeDate;
}
