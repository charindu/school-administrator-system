package sg.com.education.school.schooladminsystem.dto;

import lombok.Data;
import sg.com.education.school.schooladminsystem.dto.TeacherDTO;

import java.util.List;

@Data
public class TeacherStudentDTO {

    private List<TeacherDTO> teachers;
}
