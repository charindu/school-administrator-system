package sg.com.education.school.schooladminsystem.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.Set;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class CommonStudentDTO {
    private Set<String> students;
    /*private List<String> teachers;*/
}