package sg.com.education.school.schooladminsystem.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import sg.com.education.school.schooladminsystem.entity.Student;

import java.util.List;

@Repository
public interface StudentRepository  extends JpaRepository<Student,Long> {

    @Query(value = "SELECT student.email " +
            "FROM        student " +
            "INNER JOIN  teacher_student ON (teacher_student.student_id = student.id) " +
            "INNER JOIN  teacher ON (teacher.id = teacher_student.teacher_id) " +
            "WHERE       teacher.email in (:teachers)", nativeQuery = true)
    public List<String> findCommonStudentsByTeachers(@Param("teachers") List<String> teachers);

    public Student findByEmail(String email);
}
