package sg.com.education.school.schooladminsystem.service;

import sg.com.education.school.schooladminsystem.dto.StudentDTO;
import sg.com.education.school.schooladminsystem.entity.Student;

import java.util.List;
import java.util.Set;

public interface StudentService {

     Student registerNewStudent(StudentDTO studentDTO);

     public Set<String> findCommonStudentsByTeachers(List<String> teachers);
}
