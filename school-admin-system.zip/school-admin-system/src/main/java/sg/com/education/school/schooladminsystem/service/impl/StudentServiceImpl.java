package sg.com.education.school.schooladminsystem.service.impl;

import org.springframework.stereotype.Service;
import sg.com.education.school.schooladminsystem.dto.StudentDTO;
import sg.com.education.school.schooladminsystem.entity.Student;
import sg.com.education.school.schooladminsystem.repository.StudentRepository;
import sg.com.education.school.schooladminsystem.service.StudentService;

import java.util.List;
import java.util.Set;

@Service
public class StudentServiceImpl implements StudentService {

    private StudentRepository studentRepository;

    public StudentServiceImpl(StudentRepository studentRepository) {
        this.studentRepository = studentRepository;
    }

    public Student registerNewStudent(StudentDTO studentDTO) {
        Student student = Student.builder()
                .name( studentDTO.getName())
                .email( studentDTO.getEmail())
                .build();
        return studentRepository.save(student);
    }

    @Override
    public Set<String> findCommonStudentsByTeachers(List<String> teachers) {
        studentRepository.findCommonStudentsByTeachers(teachers);
        return null;
    }
}
