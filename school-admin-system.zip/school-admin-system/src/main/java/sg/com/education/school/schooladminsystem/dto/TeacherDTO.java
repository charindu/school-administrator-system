package sg.com.education.school.schooladminsystem.dto;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor(staticName = "teacherDTO")
public class TeacherDTO {

    @NotNull(message = "Name can not be null")
    private String name;
    private String email;

}
