package sg.com.education.school.schooladminsystem.entity;


import lombok.*;
import sg.com.education.school.schooladminsystem.common.entity.StudentTeacher;

import javax.persistence.*;
import java.util.HashSet;
import java.util.Set;

@Entity
@Table(name = "student")
@AllArgsConstructor
@Getter
@Setter
@NoArgsConstructor
@Builder
public class Student {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "id", length = 100)
    private Long id;

    @Column(name = "name")
    private String name;
    @Column(name = "email")
    private String email;

    @ManyToMany(mappedBy = "students", fetch = FetchType.LAZY)
    private Set<Teacher> teachers = new HashSet<>();
}
