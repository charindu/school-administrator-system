package sg.com.education.school.schooladminsystem.dto;

import lombok.*;

import javax.validation.constraints.NotNull;
import java.util.List;

@Setter
@Getter
@NoArgsConstructor
@AllArgsConstructor
public class StudentDTO {

    private String name;
    private String email;
    /*private List<String> teachers;*/
}
